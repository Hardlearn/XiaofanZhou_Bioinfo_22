#!/usr/bin/perl -w
use strict;

my $s = $ARGV[0];

my @s = split //, $s;

my @count = (0, 0, 0, 0);
foreach my $n (@s)	{
	if ($n eq "A")	{
		$count[0]++;
	}	elsif ($n eq "T")	{
		$count[1]++;
	}	elsif ($n eq "C")	{
		$count[2]++;
	}	elsif ($n eq "G")	{
		$count[3]++;
	}
}

print join " ", @count;
print "\n";

exit;
