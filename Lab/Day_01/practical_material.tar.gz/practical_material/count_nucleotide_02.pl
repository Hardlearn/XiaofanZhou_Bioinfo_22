#!/usr/bin/perl -w
use strict;

my $file = $ARGV[0];

open IN, "< $file" or die "Can't open $file!\n";
while (my $s = <IN>)	{
	chomp($s);

	$s =~ s/\s//g;
	my @s = split //, $s;
	
	my @count = (0, 0, 0, 0);
	foreach my $n (@s)	{
		if ($n eq "A")	{
			$count[0]++;
		}	elsif ($n eq "T")	{
			$count[1]++;
		}	elsif ($n eq "C")	{
			$count[2]++;
		}	elsif ($n eq "G")	{
			$count[3]++;
		}
	}
	
	print join " ", @count;
	print "\n";
}
close (IN);

exit;
