#!/usr/bin/python

import sys

s = sys.argv[1]

print s.count("A"), s.count("T"), s.count("C"), s.count("G")
