perl -ne '$,=" ";print y/A//, y/C//, y/G//, y/T//, \n'
