#!/usr/bin/python

import sys

filename = sys.argv[1]

file = open(filename, 'r')
for s in file:
    print s.count("A"), s.count("T"), s.count("C"), s.count("G")
